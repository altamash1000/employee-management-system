

// import React, { useState } from "react";
// import axios from "axios";

// const EmployeeForm = () => {
//   const [formData, setFormData] = useState({
//     name: "",
//     fatherName: "",
//     employeeCode: "",
//     email: "",
//     joiningDate: "",
//     post: "",
//     department: "",
//     address: "",
//     dob: "",
//     phoneNumber: ""
//   });

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       await axios.post("/api/employees", formData);
//       alert("Employee data submitted successfully!");
//       setFormData({
//         name: "",
//         fatherName: "",
//         employeeCode: "",
//         email: "",
//         joiningDate: "",
//         post: "",
//         department: "",
//         address: "",
//         dob: "",
//         phoneNumber: ""
//       });
//     } catch (error) {
//       console.error("Error submitting data: ", error);
//     }
//   };

//   return (
//     <div className="container mt-5">
//       <form onSubmit={handleSubmit}>
//         <div className="mb-3">
//           <input
//             type="text"
//             name="name"
//             value={formData.name}
//             onChange={handleChange}
//             className="form-control"
//             placeholder="Name"
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <input
//             type="text"
//             name="fatherName"
//             value={formData.fatherName}
//             onChange={handleChange}
//             className="form-control"
//             placeholder="Father's Name"
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <input
//             type="text"
//             name="employeeCode"
//             value={formData.employeeCode}
//             onChange={handleChange}
//             className="form-control"
//             placeholder="Employee Code"
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <input
//             type="email"
//             name="email"
//             value={formData.email}
//             onChange={handleChange}
//             className="form-control"
//             placeholder="Email"
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <input
//             type="text"
//             name="joiningDate"
//             value={formData.joiningDate}
//             onChange={handleChange}
//             className="form-control"
//             placeholder="Joining Date"
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <input
//             type="text"
//             name="post"
//             value={formData.post}
//             onChange={handleChange}
//             className="form-control"
//             placeholder="Post"
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <input
//             type="text"
//             name="department"
//             value={formData.department}
//             onChange={handleChange}
//             className="form-control"
//             placeholder="Department"
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <input
//             type="text"
//             name="address"
//             value={formData.address}
//             onChange={handleChange}
//             className="form-control"
//             placeholder="Address"
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <input
//             type="text"
//             name="dob"
//             value={formData.dob}
//             onChange={handleChange}
//             className="form-control"
//             placeholder="Date of Birth"
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <input
//             type="tel"
//             name="phoneNumber"
//             value={formData.phoneNumber}
//             onChange={handleChange}
//             className="form-control"
//             placeholder="Phone Number"
//             required
//           />
//         </div>
//         <div className="mb-3">
//           <button type="submit" className="btn btn-primary">
//             Submit
//           </button>
//         </div>
//       </form>
//     </div>
//   );
// };

// export default EmployeeForm;



// src/EmployeeForm.js

import React, { useState } from "react";
import axios from "axios";

const EmployeeForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    fatherName: "",
    employeeCode: "",
    email: "",
    joiningDate: "",
    post: "",
    department: "",
    address: "",
    dob: "",
    phoneNumber: ""
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("/api/employees", formData);
      alert("Submitted.");
      setFormData({
        name: "",
        fatherName: "",
        employeeCode: "",
        email: "",
        joiningDate: "",
        post: "",
        department: "",
        address: "",
        dob: "",
        phoneNumber: ""
      });
    } catch (error) {
      console.error("Error submitting data: ", error);
      alert("Error submitting data. Please try again.");
    }
  };

  
  return (
    <div className="container mt-5">
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            className="form-control"
            placeholder="Name"
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="text"
            name="fatherName"
            value={formData.fatherName}
            onChange={handleChange}
            className="form-control"
            placeholder="Father's Name"
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="text"
            name="employeeCode"
            value={formData.employeeCode}
            onChange={handleChange}
            className="form-control"
            placeholder="Employee Code"
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="form-control"
            placeholder="Email"
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="text"
            name="joiningDate"
            value={formData.joiningDate}
            onChange={handleChange}
            className="form-control"
            placeholder="Joining Date"
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="text"
            name="post"
            value={formData.post}
            onChange={handleChange}
            className="form-control"
            placeholder="Post"
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="text"
            name="department"
            value={formData.department}
            onChange={handleChange}
            className="form-control"
            placeholder="Department"
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            className="form-control"
            placeholder="Address"
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="text"
            name="dob"
            value={formData.dob}
            onChange={handleChange}
            className="form-control"
            placeholder="Date of Birth"
            required
          />
        </div>
        <div className="mb-3">
          <input
            type="tel"
            name="phoneNumber"
            value={formData.phoneNumber}
            onChange={handleChange}
            className="form-control"
            placeholder="Phone Number"
            required
          />
        </div>
        <div className="mb-3">
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default EmployeeForm;