
import React from "react";
import EmployeeForm from "./EmployeeForm";

function App() {
  return (
    <div className="App">
      <EmployeeForm />
    </div>
  );
}

export default App;

